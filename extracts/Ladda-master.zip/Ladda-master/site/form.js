import * as Ladda from '../js/ladda.js';

Ladda.bind('button[type=submit]');
